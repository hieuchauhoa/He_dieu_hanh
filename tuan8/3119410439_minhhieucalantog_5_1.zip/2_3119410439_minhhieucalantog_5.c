#include <stdio.h>
#include<pthread.h>
#include<stdlib.h>



long giaithua(int n);
int tong(int n);
void* ctc(void* arg);
void* ctc2(void* arg);


int main(int a,char* b[])
{
	if(a!=2)
			{
				printf("sai so luong phan tu \n");
				return 1;
			}
	
	int n=atoi(b[1]);
	FILE *f=fopen("fromminhhieuwithlove.txt","wt");
	fprintf(f, "%d\n",n );
	fclose(f);

	if(atof(b[1])-atoi(b[1])!=0||atoi(b[1])<0)
		{
			printf("nhap lai so\n");
			return 2;
		}
	pthread_t t1,t2;
	pthread_create(&t1,NULL,ctc,NULL);
	pthread_join (t1,NULL);
	pthread_create(&t2,NULL,ctc2,NULL);	
	pthread_join (t2,NULL);
}


long giaithua(int n)
{
	int s=1;
	while(n>0)
	{
		s=s*n;
		n--;
	}
	return s;

}

void* ctc(void* arg)
{
	int t;
	FILE *f=fopen("fromminhhieuwithlove.txt","rt");
	fscanf(f,"%d ",&t) ;
	printf("Thread factorial: %ld\n", giaithua(t));
	fclose(f);

	FILE *k=fopen("fromminhhieuwithlove.txt","wt");
	fprintf(k, "%ld\n",giaithua(t));
	fclose(k);
	
}

void* ctc2(void* arg)
{
	int l;
	FILE *p=fopen("fromminhhieuwithlove.txt","rt");
	fscanf(p,"%d",&l);
	printf("Thread sum: %d\n",tong(l) );
}

int tong(int n)
{
	int q=0;
	for(int i=1;i<=n;i++)
	{
		q=q+i;
	}
	return q;
}

